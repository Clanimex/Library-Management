package com.sayan.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sayan.Entities.Books;
import com.sayan.Service.BookService;

@RequestMapping("/booklist")
@RestController
public class BookController {

	private BookService bookService;

	public BookController(BookService bookService) {
		super();
		this.bookService = bookService;
	}

	@GetMapping
	public ResponseEntity<List<Books>> getAll() {
		List<Books> book = bookService.getAllBooks();
		return ResponseEntity.ok(book);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Books> getById(@PathVariable int id) {
		Books book = bookService.getbyId(id);
		return ResponseEntity.ok(book);
	}

	@PostMapping
	public ResponseEntity<Books> addBook(@RequestBody Books book) {
		var boi = bookService.addBook(book);
		return new ResponseEntity<>(boi, HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Books> updateBook(@PathVariable int id,@RequestBody Books book) {
		var boi2 = bookService.updateBook(id, book);
		return new ResponseEntity<>(boi2, HttpStatus.OK);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable int id){
		var boi3 = bookService.deleteBook(id);
		return new ResponseEntity<>(boi3,HttpStatus.NO_CONTENT);
	}
}
