package com.sayan.Service;

import java.util.List;

import com.sayan.Entities.Books;

public interface BookService {
	List<Books> getAllBooks();
	Books getbyId(int id);
	Books addBook(Books books);
	Books updateBook(int id, Books book);
	String deleteBook(int id);

}
