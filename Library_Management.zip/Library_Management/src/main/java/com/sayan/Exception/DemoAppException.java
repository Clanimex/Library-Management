package com.sayan.Exception;

import org.springframework.http.HttpStatus;

/**
 * Custom exception class for the Demo application. This class extends
 * RuntimeException and includes an HTTP status.
 */

public class DemoAppException extends RuntimeException {

	/**
	 * Constructor for DemoAppException.
	 *
	 * @param status  the HTTP status associated with the exception
	 * @param message the detail message for the exception
	 */
	public DemoAppException(HttpStatus status, String message) {

		super(message);
	}
}
