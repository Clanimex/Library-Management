package com.sayan.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sayan.Entities.Books;

public interface BookRepository extends JpaRepository<Books, Integer>{

}
