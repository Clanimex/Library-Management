package com.sayan.UserAuthService;

import com.sayan.UserDtos.LoginDto;

public interface UserAuthService {
	String login(LoginDto loginDto);

}
