package com.sayan.Error;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.sayan.Exception.BookNotFoundException;

@ControllerAdvice
public class ErrorHandler {
	@ExceptionHandler({ BookNotFoundException.class })
	public ResponseEntity<String> handleMovieNotFound(BookNotFoundException ex) {
		String message = ex.getMessage();
		return new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<String> handleInvalidData(HttpMessageNotReadableException ex){
    	String message = ex.getMessage();
    	return new ResponseEntity<>("Invalid Type of Data, Enter correct Format",HttpStatus.BAD_REQUEST);
    }
	@ExceptionHandler(SQLIntegrityConstraintViolationException.class)
	public ResponseEntity<String> handleInvalidData(SQLIntegrityConstraintViolationException ex){
    	String message = ex.getMessage();
    	return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);
    }
	
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<String> handleInvalidData(MethodArgumentTypeMismatchException ex){
    	String message = ex.getMessage();
    	return new ResponseEntity<>("Check the input url.Invalid Url",HttpStatus.BAD_REQUEST);
    }
	
}


