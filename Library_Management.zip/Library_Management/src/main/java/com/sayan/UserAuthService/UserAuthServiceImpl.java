package com.sayan.UserAuthService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.sayan.UserDtos.LoginDto;
import com.sayan.UserSecurity.JwtTokenProvider;

@Service
public class UserAuthServiceImpl implements UserAuthService {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Override
	public String login(LoginDto loginDto) {
		// TODO Auto-generated method stub
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				loginDto.getUsernameOrEmail(), loginDto.getPassword());
		// Authenticate the user
		Authentication authentication = authenticationManager.authenticate(token);

		// Set the authentication in the security context
		SecurityContextHolder.getContext().setAuthentication(authentication);

		// Generate a JWT token for the authenticated user
		String jwt = jwtTokenProvider.generateToken(authentication);

		return jwt;
	}

}
