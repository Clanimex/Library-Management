package com.sayan.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sayan.Entities.Books;
import com.sayan.Exception.BookNotFoundException;
import com.sayan.Repository.BookRepository;
@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository bookRepository;

	@Override
	public List<Books> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}

	@Override
	public Books getbyId(int id) {
		// TODO Auto-generated method stub
		return bookRepository.findById(id)
				.orElseThrow(() -> new BookNotFoundException("Book with id " + id + "not Found"));
	}

	@Override
	public Books addBook(Books books) {
		// TODO Auto-generated method stub
		return bookRepository.save(books);
	}

	@Override
	public Books updateBook(int id, Books book) {
		// TODO Auto-generated method stub
		Optional<Books> byId = bookRepository.findById(id);
		if(!byId.isPresent()) {
			throw new BookNotFoundException("Book with id " + id + " not found");
		}
		Books bok = byId.get();
		if(book.getAuthorName()!=null) {
			bok.setAuthorName(book.getAuthorName());
		}
		if(book.getGenre()!=null)
		{
			bok.setGenre(book.getGenre());
		}
		if(book.getName()!=null){
			bok.setName(book.getName());
		}
		if(book.getPrice()!=0) {
			bok.setPrice(book.getPrice());
		}
		return bookRepository.save(bok);
	}

	@Override
	public String deleteBook(int id) {
		// TODO Auto-generated method stub
		Optional<Books> boi = bookRepository.findById(id);
		if(boi.isEmpty()) {
			throw new BookNotFoundException("Book with id "+ id + " not found");
		}
		bookRepository.deleteById(id);
		return "Anime with id " + id + " delete succesfull";
	}

}
