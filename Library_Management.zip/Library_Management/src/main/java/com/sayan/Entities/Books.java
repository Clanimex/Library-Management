package com.sayan.Entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "Library_Books")
public class Books {
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "Book_id")
	private int id;
	
	@Column(name = "Book_Name")
	private String name;
	
	@Column(name = "Book_Price")
	private double price;
	
	@Column(name = "Genre")
	private String genre;
	
	@Column(name = "AuthorName")
	private String authorName;

}
